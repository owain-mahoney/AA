﻿namespace Payroll_GA
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txt_firstAdd = new System.Windows.Forms.TextBox();
            this.txt_passwordAdd = new System.Windows.Forms.TextBox();
            this.txt_userAdd = new System.Windows.Forms.TextBox();
            this.txt_taxAdd = new System.Windows.Forms.TextBox();
            this.txt_lastAdd = new System.Windows.Forms.TextBox();
            this.txt_hours_work = new System.Windows.Forms.TextBox();
            this.txt_hourly_wage = new System.Windows.Forms.TextBox();
            this.txt_month = new System.Windows.Forms.TextBox();
            this.txt_userpay = new System.Windows.Forms.TextBox();
            this.txt_payID = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_tax_per = new System.Windows.Forms.TextBox();
            this.txt_tax_code = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.chb_adminAdd = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            this.btn_add = new System.Windows.Forms.Button();
            this.btn_addTax = new System.Windows.Forms.Button();
            this.btn_addpay = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(67, 90);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 13);
            this.label1.TabIndex = 11;
            this.label1.Text = "Add New User";
            // 
            // txt_firstAdd
            // 
            this.txt_firstAdd.Location = new System.Drawing.Point(70, 196);
            this.txt_firstAdd.Name = "txt_firstAdd";
            this.txt_firstAdd.Size = new System.Drawing.Size(100, 20);
            this.txt_firstAdd.TabIndex = 10;
            // 
            // txt_passwordAdd
            // 
            this.txt_passwordAdd.Location = new System.Drawing.Point(70, 157);
            this.txt_passwordAdd.Name = "txt_passwordAdd";
            this.txt_passwordAdd.Size = new System.Drawing.Size(100, 20);
            this.txt_passwordAdd.TabIndex = 9;
            // 
            // txt_userAdd
            // 
            this.txt_userAdd.Location = new System.Drawing.Point(70, 115);
            this.txt_userAdd.Name = "txt_userAdd";
            this.txt_userAdd.Size = new System.Drawing.Size(100, 20);
            this.txt_userAdd.TabIndex = 8;
            // 
            // txt_taxAdd
            // 
            this.txt_taxAdd.Location = new System.Drawing.Point(70, 280);
            this.txt_taxAdd.Name = "txt_taxAdd";
            this.txt_taxAdd.Size = new System.Drawing.Size(100, 20);
            this.txt_taxAdd.TabIndex = 13;
            // 
            // txt_lastAdd
            // 
            this.txt_lastAdd.Location = new System.Drawing.Point(70, 238);
            this.txt_lastAdd.Name = "txt_lastAdd";
            this.txt_lastAdd.Size = new System.Drawing.Size(100, 20);
            this.txt_lastAdd.TabIndex = 14;
            // 
            // txt_hours_work
            // 
            this.txt_hours_work.Location = new System.Drawing.Point(274, 196);
            this.txt_hours_work.Name = "txt_hours_work";
            this.txt_hours_work.Size = new System.Drawing.Size(100, 20);
            this.txt_hours_work.TabIndex = 19;
            // 
            // txt_hourly_wage
            // 
            this.txt_hourly_wage.Location = new System.Drawing.Point(274, 284);
            this.txt_hourly_wage.Name = "txt_hourly_wage";
            this.txt_hourly_wage.Size = new System.Drawing.Size(100, 20);
            this.txt_hourly_wage.TabIndex = 18;
            // 
            // txt_month
            // 
            this.txt_month.Location = new System.Drawing.Point(274, 242);
            this.txt_month.Name = "txt_month";
            this.txt_month.Size = new System.Drawing.Size(100, 20);
            this.txt_month.TabIndex = 17;
            // 
            // txt_userpay
            // 
            this.txt_userpay.Location = new System.Drawing.Point(274, 154);
            this.txt_userpay.Name = "txt_userpay";
            this.txt_userpay.Size = new System.Drawing.Size(100, 20);
            this.txt_userpay.TabIndex = 16;
            // 
            // txt_payID
            // 
            this.txt_payID.Location = new System.Drawing.Point(274, 115);
            this.txt_payID.Name = "txt_payID";
            this.txt_payID.Size = new System.Drawing.Size(100, 20);
            this.txt_payID.TabIndex = 15;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(271, 90);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 13);
            this.label2.TabIndex = 20;
            this.label2.Text = "Add New payroll";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(465, 90);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 13);
            this.label3.TabIndex = 23;
            this.label3.Text = "Add New Tax";
            // 
            // txt_tax_per
            // 
            this.txt_tax_per.Location = new System.Drawing.Point(468, 154);
            this.txt_tax_per.Name = "txt_tax_per";
            this.txt_tax_per.Size = new System.Drawing.Size(100, 20);
            this.txt_tax_per.TabIndex = 22;
            // 
            // txt_tax_code
            // 
            this.txt_tax_code.Location = new System.Drawing.Point(468, 115);
            this.txt_tax_code.Name = "txt_tax_code";
            this.txt_tax_code.Size = new System.Drawing.Size(100, 20);
            this.txt_tax_code.TabIndex = 21;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 117);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 13);
            this.label4.TabIndex = 24;
            this.label4.Text = "username";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 157);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 13);
            this.label5.TabIndex = 25;
            this.label5.Text = "password";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(16, 202);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 13);
            this.label6.TabIndex = 26;
            this.label6.Text = "first name";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(15, 242);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(52, 13);
            this.label7.TabIndex = 27;
            this.label7.Text = "last name";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(15, 287);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 13);
            this.label8.TabIndex = 28;
            this.label8.Text = "Tax Code";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(28, 325);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(36, 13);
            this.label9.TabIndex = 29;
            this.label9.Text = "Admin";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(215, 160);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 13);
            this.label10.TabIndex = 30;
            this.label10.Text = "username";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(250, 118);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(18, 13);
            this.label11.TabIndex = 31;
            this.label11.Text = "ID";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(200, 199);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(74, 13);
            this.label12.TabIndex = 32;
            this.label12.Text = "hours_worked";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(204, 287);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(64, 13);
            this.label13.TabIndex = 33;
            this.label13.Text = "hourly wage";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(232, 245);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(36, 13);
            this.label14.TabIndex = 34;
            this.label14.Text = "month";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(411, 117);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(51, 13);
            this.label15.TabIndex = 35;
            this.label15.Text = "tax code ";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(401, 157);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(62, 13);
            this.label16.TabIndex = 36;
            this.label16.Text = "Percentage";
            // 
            // chb_adminAdd
            // 
            this.chb_adminAdd.AutoSize = true;
            this.chb_adminAdd.Location = new System.Drawing.Point(70, 325);
            this.chb_adminAdd.Name = "chb_adminAdd";
            this.chb_adminAdd.Size = new System.Drawing.Size(97, 17);
            this.chb_adminAdd.TabIndex = 37;
            this.chb_adminAdd.Text = "chb_adminAdd";
            this.chb_adminAdd.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(444, 29);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 38;
            this.button1.Text = "Home";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn_add
            // 
            this.btn_add.Location = new System.Drawing.Point(70, 374);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(75, 23);
            this.btn_add.TabIndex = 39;
            this.btn_add.Text = "Add";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // btn_addTax
            // 
            this.btn_addTax.Location = new System.Drawing.Point(468, 197);
            this.btn_addTax.Name = "btn_addTax";
            this.btn_addTax.Size = new System.Drawing.Size(75, 23);
            this.btn_addTax.TabIndex = 40;
            this.btn_addTax.Text = "Add";
            this.btn_addTax.UseVisualStyleBackColor = true;
            this.btn_addTax.Click += new System.EventHandler(this.btn_addTax_Click);
            // 
            // btn_addpay
            // 
            this.btn_addpay.Location = new System.Drawing.Point(274, 325);
            this.btn_addpay.Name = "btn_addpay";
            this.btn_addpay.Size = new System.Drawing.Size(75, 23);
            this.btn_addpay.TabIndex = 41;
            this.btn_addpay.Text = "Add";
            this.btn_addpay.UseVisualStyleBackColor = true;
            this.btn_addpay.Click += new System.EventHandler(this.btn_addpay_Click);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(579, 428);
            this.Controls.Add(this.btn_addpay);
            this.Controls.Add(this.btn_addTax);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.chb_adminAdd);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txt_tax_per);
            this.Controls.Add(this.txt_tax_code);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txt_hours_work);
            this.Controls.Add(this.txt_hourly_wage);
            this.Controls.Add(this.txt_month);
            this.Controls.Add(this.txt_userpay);
            this.Controls.Add(this.txt_payID);
            this.Controls.Add(this.txt_lastAdd);
            this.Controls.Add(this.txt_taxAdd);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_firstAdd);
            this.Controls.Add(this.txt_passwordAdd);
            this.Controls.Add(this.txt_userAdd);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form4";
            this.Text = "admin";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_firstAdd;
        private System.Windows.Forms.TextBox txt_passwordAdd;
        private System.Windows.Forms.TextBox txt_userAdd;
        private System.Windows.Forms.TextBox txt_taxAdd;
        private System.Windows.Forms.TextBox txt_lastAdd;
        private System.Windows.Forms.TextBox txt_hours_work;
        private System.Windows.Forms.TextBox txt_hourly_wage;
        private System.Windows.Forms.TextBox txt_month;
        private System.Windows.Forms.TextBox txt_userpay;
        private System.Windows.Forms.TextBox txt_payID;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_tax_per;
        private System.Windows.Forms.TextBox txt_tax_code;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.CheckBox chb_adminAdd;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.Button btn_addTax;
        private System.Windows.Forms.Button btn_addpay;
    }
}