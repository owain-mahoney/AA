﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;
namespace Payroll_GA
{
    public partial class Form3 : Form
    {
        Form1 frm1;
        public Form3(Form1 form1)
        {
            InitializeComponent();
            this.frm1 = form1;
            lb_test.Text = lb_test.Text + frm1.txt_username.Text;
        }
        private NpgsqlConnection conn;

        private DataTable dt;
        private NpgsqlCommand cmd;
        private string sql = null;

        private void Form3_Load(object sender, EventArgs e)
        {
            string connstring = String.Format("Server={0};Port={1};" +
                         "User Id={2};Password={3};Database={4};", "127.0.0.1", 5432, frm1.txt_ID.Text, frm1.txt_pass.Text, frm1.txt_database.Text);
            conn = new NpgsqlConnection(connstring);
            conn.Open();
            string temp = "'" + frm1.txt_username.Text + "'";
            sql = @"select uper from Users where USERNAME  = "+temp+";";

            cmd = new NpgsqlCommand(sql, conn);
           
            bool result = (bool)cmd.ExecuteScalar();
            conn.Close();
            if (!result)
            {
                txt_user.Enabled = false;
                btn_search.Enabled = false;
            }
            
            if (!txt_user.Enabled)
            {
                conn = new NpgsqlConnection(connstring);
                conn.Open();
                sql = @"select * from payroll where USERNAME ="+temp+"; ";            
                cmd = new NpgsqlCommand(sql, conn);
             
                dt = new DataTable();
                dt.Load(cmd.ExecuteReader());
                dgaData.DataSource = dt;
                conn.Close();
            }
                
            conn.Close();

        }

        private void btn_search_Click(object sender, EventArgs e)
        {

            try
            {
                string connstring = String.Format("Server={0};Port={1};" +
                         "User Id={2};Password={3};Database={4};", "127.0.0.1", 5432, frm1.txt_ID.Text, frm1.txt_pass.Text, frm1.txt_database.Text);
                dgaData.DataSource = null;
                conn = new NpgsqlConnection(connstring);
                string temp = "'" +txt_user.Text + "'";
                conn.Open();
                sql = @"select * from st_selectpay(:_user)";
                cmd = new NpgsqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("_user", txt_user.Text);
                dt = new DataTable();
                dt.Load(cmd.ExecuteReader());
                dgaData.DataSource = dt;
                conn.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                conn.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 MainPage = new Form2(frm1);
            MainPage.Show();
            this.Hide();
        }
    }
}
