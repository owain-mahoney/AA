﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;
namespace Payroll_GA
{
    public partial class Form2 : Form
    {
        Form1 frm1;
        private NpgsqlConnection conn;
             
        private NpgsqlCommand cmd;
        private string sql = null;
        public Form2(Form1 form1)
        {
            InitializeComponent();
            this.frm1 = form1;
        }

        private void btn_home_Click(object sender, EventArgs e)
        {

        }

        private void btn_payroll_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3(frm1) ;
            form3.Show();
            this.Hide();
        }

        private void btn_benefits_Click(object sender, EventArgs e)
        {
            Form4 form4 = new Form4(frm1);
            form4.Show();
            this.Hide();
        }

        private void btn_logout_Click(object sender, EventArgs e)
        {
            Form1 loginPage = new Form1();
            loginPage.Show();
            this.Hide();
        }

        private void btn_calculate_Click(object sender, EventArgs e)
        {
            if (txt_hours.Text != "" && txt_wage.Text != "")
            {
                viewTable.Rows.Clear();
                double wage = double.Parse(txt_wage.Text);
                int hours = int.Parse(txt_hours.Text);
                double income = wage * hours;
                double tax = 0;
                if (rdo_tax1.Checked == true)
                {
                    if (income > 12500)
                    {
                        tax = income * 0.2;
                    }

                }
                else if (rdo_tax2.Checked == true)
                {
                    tax = income * 0.2;
                }

                else if (rdo_tax3.Checked == true)
                {
                    tax = income * 0.4;
                }
                else if(rdo_taxother.Checked)
                {
                    conn.Open();
                    sql = @"";
                    cmd = new NpgsqlCommand(sql, conn);
                    conn.Close();
                }

                viewTable.Rows.Add(tax, income, (income - tax));

            }
            else
            {
                MessageBox.Show("empty info");
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            string connstring = String.Format("Server={0};Port={1};" +
                      "User Id={2};Password={3};Database={4};", "127.0.0.1", 5432, frm1.txt_ID.Text, frm1.txt_pass.Text, frm1.txt_database.Text);
            conn = new NpgsqlConnection(connstring);
            conn.Open();
            string temp = "'" + frm1.txt_username.Text + "'";
            sql = @"select uper from Users where USERNAME  = " + temp + ";";

            cmd = new NpgsqlCommand(sql, conn);

            bool result = (bool)cmd.ExecuteScalar();

            if (!result)
            {
                btn_benefits.Enabled = false;
            }
        }
    }

    //1250 = 0%
    //CBR = 20%
    //CD0 = 40%

    /*Nat Ins
     * 118-166 weekly 0%
     * 166.01-962 weekly 12%
     * 962+weekly (remainind) 2%*/

    
}
