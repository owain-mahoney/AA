﻿namespace Payroll_GA
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_user = new System.Windows.Forms.TextBox();
            this.dgaData = new System.Windows.Forms.DataGridView();
            this.lb_test = new System.Windows.Forms.Label();
            this.btn_search = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgaData)).BeginInit();
            this.SuspendLayout();
            // 
            // txt_user
            // 
            this.txt_user.Location = new System.Drawing.Point(112, 68);
            this.txt_user.Name = "txt_user";
            this.txt_user.Size = new System.Drawing.Size(143, 20);
            this.txt_user.TabIndex = 0;
            // 
            // dgaData
            // 
            this.dgaData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgaData.Location = new System.Drawing.Point(39, 132);
            this.dgaData.Margin = new System.Windows.Forms.Padding(2);
            this.dgaData.Name = "dgaData";
            this.dgaData.RowTemplate.Height = 33;
            this.dgaData.Size = new System.Drawing.Size(612, 283);
            this.dgaData.TabIndex = 1;
            // 
            // lb_test
            // 
            this.lb_test.AutoSize = true;
            this.lb_test.Location = new System.Drawing.Point(496, 71);
            this.lb_test.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_test.Name = "lb_test";
            this.lb_test.Size = new System.Drawing.Size(52, 13);
            this.lb_test.TabIndex = 3;
            this.lb_test.Text = "welcome ";
            // 
            // btn_search
            // 
            this.btn_search.Location = new System.Drawing.Point(112, 93);
            this.btn_search.Margin = new System.Windows.Forms.Padding(2);
            this.btn_search.Name = "btn_search";
            this.btn_search.Size = new System.Drawing.Size(143, 23);
            this.btn_search.TabIndex = 4;
            this.btn_search.Text = "Search";
            this.btn_search.UseVisualStyleBackColor = true;
            this.btn_search.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btn_search_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 71);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Enter User Name";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(376, 64);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 6;
            this.button1.Text = "Home";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(666, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_search);
            this.Controls.Add(this.lb_test);
            this.Controls.Add(this.dgaData);
            this.Controls.Add(this.txt_user);
            this.Name = "Form3";
            this.Text = "Payroll ";
            this.Load += new System.EventHandler(this.Form3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgaData)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_user;
        private System.Windows.Forms.DataGridView dgaData;
        private System.Windows.Forms.Label lb_test;
        private System.Windows.Forms.Button btn_search;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
    }
}