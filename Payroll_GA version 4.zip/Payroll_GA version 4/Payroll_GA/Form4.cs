﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace Payroll_GA
{
    public partial class Form4 : Form
    {
        Form1 frm1;
        private NpgsqlConnection conn;
        

        private NpgsqlCommand cmd;
        private string sql = null;
        public Form4(Form1 form1)
        {
            InitializeComponent();
            this.frm1 = form1;
            string connstring = String.Format("Server={0};Port={1};" +
                      "User Id={2};Password={3};Database={4};", "127.0.0.1", 5432, frm1.txt_ID.Text, frm1.txt_pass.Text, frm1.txt_database.Text);
            conn = new NpgsqlConnection(connstring);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 MainPage = new Form2(frm1);
            MainPage.Show();
            this.Hide();
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            try
            {
                conn.Open();
                sql = @"select st_addUser(:_id,:_password,:_ufirst,:_second,:_uper,:_tax)";

                cmd = new NpgsqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("_id", txt_userAdd.Text);
                cmd.Parameters.AddWithValue("_password", txt_passwordAdd.Text);

                cmd.Parameters.AddWithValue("_ufirst", txt_firstAdd.Text);
                cmd.Parameters.AddWithValue("_second", txt_lastAdd.Text);
                if (chb_adminAdd.Checked == true)
                {
                   cmd.Parameters.AddWithValue("_uper", true);
                }
                else
                {
                  cmd.Parameters.AddWithValue("_uper", false);
                }
               cmd.Parameters.AddWithValue("_tax",  txt_taxAdd.Text);

                if ((int)cmd.ExecuteScalar() == 1)
                {
                    MessageBox.Show("add new user");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                conn.Close();
            }


        }

        private void btn_addTax_Click(object sender, EventArgs e)
        {
            try
            {


                conn.Open();
                sql = @"select st_addtax(:_id,:_percentage)";
                cmd = new NpgsqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("_id", txt_tax_code.Text);
                cmd.Parameters.AddWithValue("_percentage", float.Parse(txt_tax_per.Text));

                if ((int)cmd.ExecuteScalar() == 1)
                {
                    MessageBox.Show("add new tax code");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                conn.Close();
            }
        }

        private void btn_addpay_Click(object sender, EventArgs e)
        {
            try
            {


                conn.Open();
                sql = @"select st_addpay(:_id,:_username,:_hours_worked,:_month,:_hourly_wage)";
                cmd = new NpgsqlCommand(sql, conn);

                cmd.Parameters.AddWithValue("_id", Convert.ToInt32(txt_payID.Text));
                cmd.Parameters.AddWithValue("_username", txt_userpay.Text);
                cmd.Parameters.AddWithValue("_hours_worked", Convert.ToInt32(txt_hours_work.Text));
                cmd.Parameters.AddWithValue("_month", txt_month.Text);
                cmd.Parameters.AddWithValue("_hourly_wage", float.Parse(txt_hourly_wage.Text));

                if ((int)cmd.ExecuteScalar() == 1)
                {
                    MessageBox.Show("added new payroll");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                conn.Close();
            }
        }
    }
}
